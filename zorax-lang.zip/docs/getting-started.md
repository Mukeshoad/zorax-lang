# Getting Started with ZORAX

Clone the repo and run: `python main.py examples/hello_world.zx`
