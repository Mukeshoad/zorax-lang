# Roadmap

- v1.0: Basic Commands
- v1.1: Loops
- v2.0: Functions and more
