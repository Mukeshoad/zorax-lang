# ZORAX Syntax

- `@set var = value`
- `@show "text"`
- `@if condition`
- `@end`
