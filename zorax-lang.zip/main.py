# Entry point for running ZORAX programs
