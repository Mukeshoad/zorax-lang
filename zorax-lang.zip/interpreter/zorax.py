# ZORAX interpreter core logic
