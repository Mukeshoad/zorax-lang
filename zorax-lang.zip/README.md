# ZORAX – The Language of Simplicity & Power

ZORAX is a minimal programming language created to be readable, expressive, and beginner-friendly.
